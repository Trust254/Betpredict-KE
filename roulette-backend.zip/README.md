# Roulette Analyzer Backend

## 1. Install

Make sure Node.js 18+ is installed, then run:

```bash
npm install
```

## 2. Start

```bash
npm start
```

The server normally runs at:

`http://localhost:3000`

## 3. Test

Open:

`http://localhost:3000/health`

Then:

`http://localhost:3000/api/roulette-history`

## 4. Add one result

Send a POST request to:

`/api/roulette-result`

with:

```json
{
  "number": 17
}
```

## 5. Add several results

POST to:

`/api/roulette-history`

with:

```json
{
  "spins": [17, 32, 0, 5, 21]
}
```

The first number is treated as the newest result.

## Important

This backend does not scrape, bypass, or authenticate to Betika. For genuine live Betika results, connect an authorized data/API source to this backend.
